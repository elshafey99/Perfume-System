<?php echo e($slot); ?>

<?php /**PATH C:\Users\Elshaf3ey\Desktop\Work\Herd\Perfume-System\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>