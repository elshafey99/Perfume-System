<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="<?php echo e(Config::get('app.locale') == 'ar' ? 'rtl' : 'ltr'); ?>">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0,minimal-ui">
    <?php
        $setting = \App\Models\Setting::first();
    ?>
    <meta name="description" content="<?php echo e($setting->meta_desc); ?>">
    <meta name="keywords"
        content="admin template, Vuexy admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>Dashboard | <?php echo e($title); ?></title>
    <link rel="apple-touch-icon" href="<?php echo e(asset('dashboard')); ?>/app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset($setting->favicon)); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600"
        rel="stylesheet">

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Config::get('app.locale') == 'ar'): ?>
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/vendors/css/vendors-rtl.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/bootstrap.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/bootstrap-extended.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/colors.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/components.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/themes/dark-layout.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/themes/bordered-layout.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/themes/semi-dark-layout.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/core/menu/menu-types/vertical-menu.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/plugins/forms/form-validation.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/pages/authentication.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css-rtl/custom-rtl.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/assets/css/style-rtl.css">
    <?php else: ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/vendors/css/vendors.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css/bootstrap-extended.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css/colors.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css/components.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css/themes/dark-layout.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css/themes/bordered-layout.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css/themes/semi-dark-layout.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css/core/menu/menu-types/vertical-menu.css">
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('dashboard')); ?>/app-assets/css/plugins/forms/form-validation.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css/pages/authentication.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/app-assets/css/custom.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard')); ?>/assets/css/style.css">
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern blank-page navbar-floating footer-static  " data-open="click"
    data-menu="vertical-menu-modern" data-col="blank-page">
    <nav class="header-navbar navbar navbar-expand-lg align-items-center  navbar-light navbar-shadow container-xxl">
        <div class="navbar-container d-flex content">
            <ul class="nav navbar-nav bookmark-icons">
                <li class="nav-item d-none d-lg-block">
                    
                </li>
            </ul>
            <ul class="nav navbar-nav align-items-center ms-auto">
                <li class="nav-item dropdown dropdown-language"><a class="nav-link dropdown-toggle"
                        id="dropdown-flag" href="#" data-bs-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false">
                        <i class="flag-icon flag-icon-<?php echo e(Config::get('app.locale') == 'ar' ? 'eg' : 'us'); ?>"></i><span
                            class="selected-language"><?php echo e(Config::get('app.locale') == 'ar' ? 'العربية' : 'English'); ?></span></a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdown-flag">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" hreflang="<?php echo e($localeCode); ?>"
                                href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>"
                                data-language="en">
                                <i class="flag-icon flag-icon-<?php echo e($localeCode == 'ar' ? 'eg' : 'us'); ?>"></i>
                                <?php echo e($properties['native']); ?>

                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                    </div>
                </li>
            </ul>
        </div>
    </nav>
    <!-- BEGIN: Content-->
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <div class="auth-wrapper auth-basic px-2">
                    <div class="auth-inner my-2">
                        <!-- Login basic -->
                        <div class="card mb-0">
                            <div class="card-body">
                                <a class="brand-logo d-flex align-items-center">
                                    <img src="<?php echo e(asset($setting->logo)); ?>" width="80" alt="Logo">
                                    <h2 class="brand-text text-primary mb-0"><?php echo e($setting->site_name); ?></h2>
                                </a>

                                <?php echo $__env->yieldContent('content'); ?>
                            </div>
                        </div>
                        <!-- /Login basic -->
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- END: Content-->


    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(asset('dashboard')); ?>/app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('dashboard')); ?>/app-assets/vendors/js/forms/validation/jquery.validate.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('dashboard')); ?>/app-assets/js/core/app-menu.js"></script>
    <script src="<?php echo e(asset('dashboard')); ?>/app-assets/js/core/app.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="<?php echo e(asset('dashboard')); ?>/app-assets/js/scripts/pages/auth-login.js"></script>
    <!-- END: Page JS-->

    <script>
        $(window).on('load', function() {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        })
    </script>
    

</body>
<!-- END: Body-->

</html>
<?php /**PATH C:\Users\Elshaf3ey\Desktop\Work\Herd\Education-Academy\resources\views/dashboard/auth/partials/auth.blade.php ENDPATH**/ ?>