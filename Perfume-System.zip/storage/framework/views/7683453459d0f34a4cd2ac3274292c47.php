<?php $__env->startSection('settings-active', 'active'); ?>
<?php $__env->startSection('settings-open', 'open'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo e(__('dashboard.settings')); ?></h4>
                </div>
                <div class="table-responsive">
                    <div class="card-body">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('dashboard.settings.update-settings');

$key = null;

$key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-3556266454-0', null);

$__html = app('livewire')->mount($__name, $__params, $key);

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Livewire.on('settingUpdateMS', function() {
                Swal.fire({
                    position: 'top-start',
                    icon: 'success',
                    title: '<?php echo e(__('dashboard.settings-update-successfully')); ?>',
                    showConfirmButton: false,
                    timer: 1500,
                    customClass: {
                        confirmButton: 'btn btn-primary'
                    },
                    buttonsStyling: false
                });
            });
        });
    </script>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.master', ['title' => 'Settings'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Elshaf3ey\Desktop\Work\Herd\Education-Academy\resources\views/dashboard/settings/index.blade.php ENDPATH**/ ?>