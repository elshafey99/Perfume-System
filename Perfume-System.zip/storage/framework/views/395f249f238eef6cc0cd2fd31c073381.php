<div>
    <form class="form form-horizontal" wire:submit.prevent='submit'>
        <div class="row">
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.site-name-ar')); ?></label>
                <input type="text" class="form-control" wire:model="site_name_ar"
                    placeholder="<?php echo e(__('dashboard.site-name-ar')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'site_name_ar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.site-name')); ?></label>
                <input type="text" class="form-control" wire:model="site_name"
                    placeholder="<?php echo e(__('dashboard.site-name')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'site_name'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <div class="row">
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.site-address-ar')); ?></label>
                <input type="text" class="form-control" wire:model="site_address_ar"
                    placeholder="<?php echo e(__('dashboard.site-name-ar')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'site_address_ar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.site-address')); ?></label>
                <input type="text" class="form-control" wire:model="site_address"
                    placeholder="<?php echo e(__('dashboard.site-name')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'site_address'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <div class="row">
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.site-email')); ?></label>
                <input type="email" class="form-control" wire:model="site_email"
                    placeholder="<?php echo e(__('dashboard.site-name-ar')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'site_email'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.email-support')); ?></label>
                <input type="email" class="form-control" wire:model="email_support"
                    placeholder="<?php echo e(__('dashboard.site-name')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'email_support'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <div class="row">
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.site-phone')); ?></label>
                <input type="text" class="form-control" wire:model="site_phone"
                    placeholder="<?php echo e(__('dashboard.site-phone')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'site_phone'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        <div class="mb-2">
            <label class="d-block form-label"><?php echo e(__('dashboard.site-desc-ar')); ?></label>
            <textarea class="form-control" rows="3" wire:model="site_desc_ar"></textarea>
            <?php echo $__env->make('dashboard.includes.error', ['property' => 'site_desc_ar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <div class="mb-2">
            <label class="d-block form-label"><?php echo e(__('dashboard.site-desc')); ?></label>
            <textarea class="form-control" rows="3" wire:model="site_desc"></textarea>
            <?php echo $__env->make('dashboard.includes.error', ['property' => 'site_desc'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <div class="mb-2">
            <label class="d-block form-label"><?php echo e(__('dashboard.about-ar')); ?></label>
            <textarea class="form-control" rows="3" wire:model="about_ar"></textarea>
            <?php echo $__env->make('dashboard.includes.error', ['property' => 'about_ar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <div class="mb-2">
            <label class="d-block form-label"><?php echo e(__('dashboard.about-en')); ?></label>
            <textarea class="form-control" rows="3" wire:model="about_en"></textarea>
            <?php echo $__env->make('dashboard.includes.error', ['property' => 'about_en'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        
        <h2 class="text-center mt-2" style="color: blue"><?php echo e(__('dashboard.social-media')); ?></h2>
        <hr style="color: blue" class="mb-2">

        <div class="row">
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.facebook-url')); ?></label>
                <input type="text" class="form-control" wire:model="facebook"
                    placeholder="<?php echo e(__('dashboard.facebook-url')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'facebook'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </div>
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.x-url')); ?></label>
                <input type="text" class="form-control" wire:model="x_url"
                    placeholder="<?php echo e(__('dashboard.x-url')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'x_url'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </div>
        </div>

        <div class="row">
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.youtube-url')); ?></label>
                <input type="text" class="form-control" wire:model="youtube"
                    placeholder="<?php echo e(__('dashboard.youtube-url')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'youtube'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
        

        
        <h2 class="text-center mt-2" style="color: blue"><?php echo e(__('dashboard.media')); ?></h2>
        <hr style="color: blue" class="mb-2">

        <div class="row mb-2">
            <div class="col-6">
                <div class="col-sm-6">
                    <label class="col-form-label"><?php echo e(__('dashboard.logo')); ?></label>
                </div>
                <div class="form-group">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($logo) && is_object($logo)): ?>
                        <img src="<?php echo e($logo->temporaryUrl()); ?>" width="150" class="wd-80 ">
                    <?php else: ?>
                        <img src="<?php echo e(asset($logo)); ?>" width="150" class="wd-80 ">
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="col-sm-9">
                    <input type="file" class="form-control" wire:model="logo">
                    <?php echo $__env->make('dashboard.includes.error', ['property' => 'logo'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
            <div class="col-6">
                <div class="col-sm-6">
                    <label class="col-form-label"><?php echo e(__('dashboard.site-favicon')); ?></label>
                </div>
                <div class="form-group">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($favicon) && is_object($favicon)): ?>
                        <img src="<?php echo e($favicon->temporaryUrl()); ?>" width="150" class="wd-80 ">
                    <?php else: ?>
                        <img src="<?php echo e(asset($favicon)); ?>" width="150" class="wd-80 ">
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="col-sm-9">
                    <input type="file" class="form-control" wire:model="favicon">
                    <?php echo $__env->make('dashboard.includes.error', ['property' => 'favicon'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </div>
        

        
        <h2 class="text-center mt-2" style="color: blue"><?php echo e(__('dashboard.uther')); ?></h2>
        <hr style="color: blue" class="mb-2">

        <div class="mb-2">
            <label class="d-block form-label"><?php echo e(__('dashboard.meta-desc-ar')); ?></label>
            <textarea class="form-control" rows="3" wire:model="meta_desc_ar"></textarea>
            <?php echo $__env->make('dashboard.includes.error', ['property' => 'meta_desc_ar'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <div class="mb-2">
            <label class="d-block form-label"><?php echo e(__('dashboard.meta-desc')); ?></label>
            <textarea class="form-control" rows="3" wire:model="meta_desc"></textarea>
            <?php echo $__env->make('dashboard.includes.error', ['property' => 'meta_desc'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <div class="row">
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.site-copyright')); ?></label>
                <input type="text" class="form-control" wire:model="site_copyright"
                    placeholder="<?php echo e(__('dashboard.site-copyright')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'site_copyright'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="mb-1 col-md-6">
                <label class="form-label"><?php echo e(__('dashboard.site-promo')); ?></label>
                <input type="text" class="form-control" wire:model="promotion_url"
                    placeholder="<?php echo e(__('dashboard.site-promo')); ?>">
                <?php echo $__env->make('dashboard.includes.error', ['property' => 'promotion_url'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
        

        <button type="submit"
            class="btn btn-primary waves-effect waves-float waves-light"><?php echo e(__('dashboard.submit')); ?></button>
    </form>
</div>
<?php /**PATH C:\Users\Elshaf3ey\Desktop\Work\Herd\Education-Academy\resources\views/dashboard/settings/update-settings.blade.php ENDPATH**/ ?>