<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;
use Illuminate\Auth\AuthenticationException;

class Handler extends ExceptionHandler
{
    /**
     * The list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     */
    public function register(): void
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }

    /**
     * 🔐 معالجة محاولات الدخول غير المصرح بها (unauthenticated)
     */
    protected function unauthenticated($request, AuthenticationException $exception)
    {
        // لو الطلب من لوحة التحكم أو Livewire request
        if ($request->is('*/dashboard/*') || $request->hasHeader('X-Livewire')) {
            return redirect()->guest(route('dashboard.login'));
        }

        // لأي حالة أخرى (افتراضي)
        return redirect()->guest(route('dashboard.login'));
    }
}
