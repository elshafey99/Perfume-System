<?php

return [
    'profile_retrieved_successfully' => 'تم جلب الملف الشخصي بنجاح',
    'profile_updated_successfully' => 'تم تحديث الملف الشخصي بنجاح',
    'profile_update_failed' => 'فشل تحديث الملف الشخصي',
    'password_changed_successfully' => 'تم تغيير كلمة المرور بنجاح',
    'current_password_incorrect' => 'كلمة المرور الحالية غير صحيحة',
    'email_already_exists' => 'البريد الإلكتروني مستخدم بالفعل',
];
