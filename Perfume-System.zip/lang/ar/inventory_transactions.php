<?php

return [
    'transactions_retrieved_successfully' => 'تم جلب حركات المخزون بنجاح',
    'transaction_retrieved_successfully' => 'تم جلب حركة المخزون بنجاح',
    'transaction_created_successfully' => 'تم إنشاء حركة المخزون بنجاح',
    'transaction_deleted_successfully' => 'تم حذف حركة المخزون بنجاح',
    'transaction_not_found' => 'حركة المخزون غير موجودة',
    'transaction_creation_failed' => 'فشل إنشاء حركة المخزون',
    'transaction_deletion_failed' => 'فشل حذف حركة المخزون',
];

